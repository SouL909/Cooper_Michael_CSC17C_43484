/* 
 * File:   main.cpp
 * Author: Michael Cooper
 * Created on 4/27/22, 8:00 AM
 * Purpose: Project 1 - Connect 4 - Version 3
 * Succesfully finished corresponding cpp files and have met most requirements
 * planning to add text files that will keep track of leaderboard, saving, etc.
 */

#include "Game.h"
#include "Board.h"
//Starts the game
int main() {
  Game game;
  game.start();
}