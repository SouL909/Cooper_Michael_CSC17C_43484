/* 
 * File:   main.cpp
 * Author: Michael Cooper
 * Created on 4/15/22, 8:00 AM
 * Purpose: Project 1 - Connect 4 - Version 2
 */

//Created Gamestate header file to keep track of the gamestate and made source 
//files for the previously made header files.
//Still need to make gamestate source file and troubleshoot
//Build does not yet run

#include "Game.h"
#include "Board.h"

//Starts the game
int main() {
  Game game;
  game.start();
}