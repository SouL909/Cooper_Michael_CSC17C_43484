/* 
 * File:   main.cpp
 * Author: Michael Cooper
 * Created on 4/15/22, 8:00 AM
 * Purpose: Project 1 - Connect 4 - Version 1
 */

//Starting maping out the header files for the project for the game, board, and players 
// with respective classes and requirements. Still need to make header file for the game state itself and source files
//Build does not yet run

#include "Game.h"
#include "Board.h"

//Starts the game
int main() {
  Game game;
  game.start();
}