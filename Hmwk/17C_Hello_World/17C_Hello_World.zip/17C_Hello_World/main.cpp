/* 
 * File:   main.cpp
 * Author: Michael Cooper
 * Created on February 16, 2023, 9:00PM
 * Purpose: Hello World
 */

//System Libraries
#include <iostream>   //Input/Output Library
using namespace std;  //STD Name-space where Library is compiled

//User Libraries

//Global Constants not Variables
//Math/Physics/Science/Conversions/Dimensions

//Function Prototypes

//Code Begins Execution Here with function main
int main(int argc, char** argv) {
    //Set random number seed once here
    
    //Declare variables here
    
    //Initialize variables here
    
    //Map inputs to outputs here, i.e. the process
    
    //Display the results
    cout << "Hello World!";

    return 0;
}
